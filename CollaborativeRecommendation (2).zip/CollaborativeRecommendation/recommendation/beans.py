
class ProductBean:

    def __init__(self,product,comments,rating,description):

        self.product=product
        self.comments=comments
        self.rating=rating
        self.description=description
